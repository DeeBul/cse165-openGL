make
./glutapp
