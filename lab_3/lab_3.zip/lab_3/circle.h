#ifndef circle_h
#define circle_h

class {
	float r;

	bool drag;

	bool inside;
}